"use client";
import { useState } from "react";

export default function ContactForm() {
  const [status, setStatus] = useState("idle");

  async function onSubmit(e) {
    e.preventDefault();
    setStatus("sending");
    const data = Object.fromEntries(new FormData(e.target));
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error();
      e.target.reset();
      setStatus("sent");
    } catch {
      setStatus("error");
    }
  }

  return (
    <form onSubmit={onSubmit} className="form">
      <input name="name" placeholder="Your name" required />
      <input name="email" type="email" placeholder="Your email" required />
      <textarea name="message" rows={4} placeholder="How can we help?" required />
      <button disabled={status === "sending"}>{status === "sending" ? "Sending..." : "Send message"}</button>
      {status === "sent" && <p className="ok">Thank you! We will reply soon.</p>}
      {status === "error" && <p className="err">Something went wrong. Please try again.</p>}
    </form>
  );
}
