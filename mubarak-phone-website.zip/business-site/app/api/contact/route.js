import { NextResponse } from "next/server";
import { getDb } from "@/lib/mongodb";
import { isAuthorized } from "@/lib/auth";

export const dynamic = "force-dynamic";

// POST /api/contact -> public, saves a customer message
export async function POST(req) {
  const { name, email, message } = await req.json();
  if (!name || !email || !message)
    return NextResponse.json({ error: "name, email and message are required" }, { status: 400 });
  const db = await getDb();
  await db.collection("messages").insertOne({
    name: String(name).slice(0, 100),
    email: String(email).slice(0, 200),
    message: String(message).slice(0, 2000),
    createdAt: new Date(),
  });
  return NextResponse.json({ ok: true }, { status: 201 });
}

// GET /api/contact -> list messages (needs x-api-key)
export async function GET(req) {
  if (!isAuthorized(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const db = await getDb();
  const msgs = await db.collection("messages").find().sort({ createdAt: -1 }).toArray();
  return NextResponse.json(msgs);
}
