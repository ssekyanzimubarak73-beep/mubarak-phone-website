import { NextResponse } from "next/server";
import { getDb } from "@/lib/mongodb";
import { isAuthorized } from "@/lib/auth";

export const dynamic = "force-dynamic";

// GET /api/items  -> list all
export async function GET() {
  const db = await getDb();
  const items = await db.collection("items").find().sort({ createdAt: -1 }).toArray();
  return NextResponse.json(items);
}

// POST /api/items  -> create (needs x-api-key)
export async function POST(req) {
  if (!isAuthorized(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const body = await req.json();
  if (!body.name) return NextResponse.json({ error: "name is required" }, { status: 400 });
  const doc = {
    name: String(body.name),
    description: String(body.description || ""),
    price: Number(body.price) || 0,
    image: String(body.image || ""),
    createdAt: new Date(),
  };
  const db = await getDb();
  const result = await db.collection("items").insertOne(doc);
  return NextResponse.json({ _id: result.insertedId, ...doc }, { status: 201 });
}
