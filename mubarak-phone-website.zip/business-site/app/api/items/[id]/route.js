import { NextResponse } from "next/server";
import { ObjectId } from "mongodb";
import { getDb } from "@/lib/mongodb";
import { isAuthorized } from "@/lib/auth";

export const dynamic = "force-dynamic";

const bad = () => NextResponse.json({ error: "Invalid id" }, { status: 400 });

export async function GET(_req, { params }) {
  if (!ObjectId.isValid(params.id)) return bad();
  const db = await getDb();
  const item = await db.collection("items").findOne({ _id: new ObjectId(params.id) });
  return item ? NextResponse.json(item) : NextResponse.json({ error: "Not found" }, { status: 404 });
}

// PUT /api/items/:id -> update (needs x-api-key)
export async function PUT(req, { params }) {
  if (!isAuthorized(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (!ObjectId.isValid(params.id)) return bad();
  const body = await req.json();
  const update = {};
  for (const k of ["name", "description", "image"]) if (body[k] !== undefined) update[k] = String(body[k]);
  if (body.price !== undefined) update.price = Number(body.price) || 0;
  update.updatedAt = new Date();
  const db = await getDb();
  const result = await db
    .collection("items")
    .findOneAndUpdate({ _id: new ObjectId(params.id) }, { $set: update }, { returnDocument: "after" });
  return result ? NextResponse.json(result) : NextResponse.json({ error: "Not found" }, { status: 404 });
}

// DELETE /api/items/:id (needs x-api-key)
export async function DELETE(req, { params }) {
  if (!isAuthorized(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (!ObjectId.isValid(params.id)) return bad();
  const db = await getDb();
  const result = await db.collection("items").deleteOne({ _id: new ObjectId(params.id) });
  return result.deletedCount
    ? NextResponse.json({ deleted: true })
    : NextResponse.json({ error: "Not found" }, { status: 404 });
}
