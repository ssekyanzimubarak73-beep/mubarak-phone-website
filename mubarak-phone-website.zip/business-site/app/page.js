import { getDb } from "@/lib/mongodb";
import ContactForm from "@/components/ContactForm";

export const dynamic = "force-dynamic";

const WHATSAPP = "256709550387"; // 0709550387 in international format (Uganda)
const EMAIL = "ssekyanzimubarak73@gmail.com";
const CALL = "0704439550";
const LOCATION = "Seeta, Mukono, Uganda";
const MAP = "https://www.google.com/maps/search/?api=1&query=Seeta+Mukono+Uganda";
const HOURS = [
  ["Monday - Friday", "8:00 AM - 6:00 PM"],
  ["Saturday", "8:00 AM - 6:00 PM"],
  ["Sunday", "Closed"],
];

// ✏️ EDIT YOUR PRICES HERE (UGX). These are example starting prices.
const repairPrices = [
  ["Screen replacement", 50000],
  ["Battery replacement", 30000],
  ["Charging port repair", 25000],
  ["Water damage cleaning", 40000],
  ["Software / flashing", 20000],
  ["Speaker or mic repair", 25000],
];
const accessoryPrices = [
  ["Screen protector", 5000],
  ["Phone case", 10000],
  ["Fast charger", 20000],
  ["Earphones", 10000],
  ["Power bank", 50000],
  ["Memory card", 25000],
];

async function getItems() {
  try {
    const db = await getDb();
    const items = await db.collection("items").find().sort({ createdAt: -1 }).toArray();
    return items.map((i) => ({ ...i, _id: i._id.toString() }));
  } catch {
    return [];
  }
}

const services = [
  { icon: "🔧", title: "Screen Repair", text: "Cracked or dead screens replaced fast." },
  { icon: "🔋", title: "Battery Replacement", text: "Bring your phone back to full day power." },
  { icon: "⚡", title: "Charging Port Fix", text: "Slow or loose charging solved properly." },
  { icon: "💧", title: "Water Damage", text: "Cleaning and recovery for wet phones." },
  { icon: "📱", title: "Software & Unlocking", text: "Updates, hanging phones and software issues." },
  { icon: "🎧", title: "Accessories", text: "Chargers, cases, earphones, protectors and more." },
];

export default async function Home() {
  const items = await getItems();
  return (
    <>
      <header className="nav">
        <strong className="logo">Mubarak <span>Phone</span></strong>
        <nav>
          <a href="#services">Repairs</a>
          <a href="#prices">Prices</a>
          <a href="#shop">Accessories</a>
          <a href="#contact">Contact</a>
        </nav>
      </header>

      <section className="hero">
        <p className="tag">📍 {LOCATION}</p>
        <h1>Your phone fixed <em>fast</em>.<br />Accessories you can trust.</h1>
        <p className="sub">Quality repairs and original accessories at fair prices. Message us on WhatsApp for a quick quote.</p>
        <div className="actions">
          <a className="btn" href={`https://wa.me/${WHATSAPP}`} target="_blank" rel="noreferrer">💬 Chat on WhatsApp</a>
          <a className="btn ghost" href="#shop">View accessories</a>
        </div>
      </section>

      <section id="services" className="section">
        <h2>Repair services</h2>
        <div className="grid">
          {services.map((s) => (
            <article key={s.title} className="card">
              <div className="icon">{s.icon}</div>
              <h3>{s.title}</h3>
              <p>{s.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section id="prices" className="section">
        <h2>Price list</h2>
        <div className="prices">
          <div className="card">
            <h3>🔧 Repairs</h3>
            <ul className="plist">
              {repairPrices.map(([n, v]) => (
                <li key={n}><span>{n}</span><b>from UGX {v.toLocaleString()}</b></li>
              ))}
            </ul>
          </div>
          <div className="card">
            <h3>🎧 Accessories</h3>
            <ul className="plist">
              {accessoryPrices.map(([n, v]) => (
                <li key={n}><span>{n}</span><b>from UGX {v.toLocaleString()}</b></li>
              ))}
            </ul>
          </div>
        </div>
        <p className="muted note">Final price depends on your phone model. Send us your phone model on WhatsApp for an exact quote.</p>
      </section>

      <section id="shop" className="section">
        <h2>Accessories</h2>
        {items.length === 0 ? (
          <p className="muted">Products coming soon. Ask us on WhatsApp for what is in stock.</p>
        ) : (
          <div className="grid">
            {items.map((i) => (
              <article key={i._id} className="card">
                {i.image && <img src={i.image} alt={i.name} />}
                <h3>{i.name}</h3>
                <p>{i.description}</p>
                {i.price > 0 && <span className="price">UGX {i.price.toLocaleString()}</span>}
                <a className="order" href={`https://wa.me/${WHATSAPP}?text=${encodeURIComponent("Hello, I want: " + i.name)}`} target="_blank" rel="noreferrer">Order on WhatsApp</a>
              </article>
            ))}
          </div>
        )}
      </section>

      <section id="contact" className="section contact">
        <div>
          <h2>Contact us</h2>
          <p className="muted">Visit, call or message us. We reply quickly.</p>
          <ul className="info">
            <li>💬 WhatsApp: <a href={`https://wa.me/${WHATSAPP}`}>0709550387</a></li>
            {CALL && <li>📞 Call: <a href={`tel:${CALL}`}>{CALL}</a></li>}
            <li>📍 <a href={MAP} target="_blank" rel="noreferrer">{LOCATION}</a></li>
            <li>✉️ Email: <a href={`mailto:${EMAIL}`}>{EMAIL}</a></li>
          </ul>
          <h3 className="hrs">🕗 Working hours</h3>
          <ul className="plist hours">
            {HOURS.map(([d, t]) => (
              <li key={d}><span>{d}</span><b>{t}</b></li>
            ))}
          </ul>
        </div>
        <ContactForm />
      </section>

      <a className="float" href={`https://wa.me/${WHATSAPP}`} target="_blank" rel="noreferrer" aria-label="WhatsApp">💬</a>
      <footer className="footer">© {new Date().getFullYear()} Mubarak Phone Accessories and Repair · {LOCATION}</footer>
    </>
  );
}
