import "./globals.css";

export const metadata = {
  title: "Mubarak Phone Accessories and Repair",
  description: "Phone repairs and phone accessories in Seeta, Mukono, Uganda. Prices in UGX. Chat with us on WhatsApp.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
